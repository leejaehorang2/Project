#pragma once

void init_debug_module(MblMwMetaWearBoard *board);
void free_debug_module(void *state);
