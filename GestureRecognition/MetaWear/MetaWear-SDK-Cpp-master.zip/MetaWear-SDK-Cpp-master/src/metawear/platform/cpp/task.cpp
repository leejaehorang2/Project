#include "task.h"

Task::~Task() { }
