#include <stdint.h>

#include "dataprocessor_fwd.h"
#include "metawear/core/datasignal_fwd.h"
#include "metawear/platform/dllmarker.h"
