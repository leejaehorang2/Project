#pragma once

enum class AmbientLightLtr329Register : uint8_t {
    ENABLE = 1,
    CONFIG,
    OUTPUT,
};
