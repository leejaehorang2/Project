#pragma once

enum class ColorDetectorTcs34725Register : uint8_t {
    RGB_COLOR= 1,
    MODE
};
