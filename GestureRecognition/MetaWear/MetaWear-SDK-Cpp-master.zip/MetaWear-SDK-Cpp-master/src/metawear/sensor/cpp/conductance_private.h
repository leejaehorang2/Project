#pragma once

#include "metawear/core/metawearboard_fwd.h"

void init_conductance_module(MblMwMetaWearBoard *board);
