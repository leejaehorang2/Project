#pragma once

enum class HumidityBme280Register : uint8_t {
    HUMIDITY= 1,
    MODE
};
