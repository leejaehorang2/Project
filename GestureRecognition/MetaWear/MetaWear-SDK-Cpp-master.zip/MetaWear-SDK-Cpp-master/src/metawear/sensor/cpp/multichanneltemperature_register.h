#pragma once

enum class MultiChannelTempRegister : uint8_t {
    TEMPERATURE = 1,
    MODE
};
