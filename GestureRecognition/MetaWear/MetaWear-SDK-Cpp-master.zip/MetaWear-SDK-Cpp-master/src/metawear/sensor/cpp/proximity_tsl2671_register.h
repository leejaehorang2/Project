#pragma once

enum class ProximityTsl2671Register : uint8_t {
    PROXIMITY= 1,
    MODE
};
